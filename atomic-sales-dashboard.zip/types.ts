// Domain Types
export interface SalesData {
  id: string;
  month: string;
  sales: number;
  year: number;
  status: 'Completed' | 'Pending' | 'Refunded';
  customerCount: number;
}

export type ChartType = 'bar' | 'line' | 'area';
export type ViewType = 'dashboard' | 'transactions' | 'settings';

export interface FilterState {
  year: number | 'all';
  threshold: number;
  chartType: ChartType;
}

// Component Prop Types
export interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  description?: string;
  action?: React.ReactNode;
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger';
  isLoading?: boolean;
  icon?: React.ReactNode;
}

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: { label: string; value: string | number }[];
}
