import { SalesData } from './types';

export const MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

// Helper to generate random consistent data for demo purposes
const generateData = (year: number, baseline: number, variance: number): SalesData[] => {
  return MONTHS.map((month, index) => {
    const sales = Math.floor(baseline + Math.random() * variance);
    // Simulate some realistic status logic
    const randomStatus = Math.random();
    let status: 'Completed' | 'Pending' | 'Refunded' = 'Completed';
    if (randomStatus > 0.95) status = 'Refunded';
    else if (randomStatus > 0.9) status = 'Pending';

    return {
      id: `TRX-${year}-${index + 100}`,
      month,
      year,
      sales,
      status,
      customerCount: Math.floor(sales / 120) // Avg order value approx $120
    };
  });
};

export const MOCK_SALES_DATA: SalesData[] = [
  ...generateData(2022, 15000, 10000), // 2022 Data
  ...generateData(2023, 18000, 12000), // 2023 Data (Growth)
  ...generateData(2024, 22000, 15000), // 2024 Data (Higher Growth)
];

export const APP_CONFIG = {
  currency: 'USD',
  locale: 'en-US',
};
