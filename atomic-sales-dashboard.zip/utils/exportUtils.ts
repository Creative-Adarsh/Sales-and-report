import { SalesData } from '../types';

export const downloadCSV = (data: SalesData[], filename: string = 'sales-report.csv') => {
  if (!data || data.length === 0) return;

  const headers = ['ID', 'Year', 'Month', 'Sales', 'Customers', 'Status'];
  const csvContent = [
    headers.join(','),
    ...data.map(row => [
      row.id,
      row.year,
      row.month,
      row.sales,
      row.customerCount,
      row.status
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const printReport = () => {
  window.print();
};
