# Atomic Sales Dashboard

A modern, responsive sales dashboard built with React, TypeScript, and Tailwind CSS using Atomic Design principles.

## Features

- **Data Visualization**: Interactive charts (Bar, Line, Area) using `recharts`.
- **Filtering**: Filter sales data by Year and Minimum Sales Threshold.
- **AI Integration**: Uses Google Gemini API (`@google/genai`) to provide textual analysis and actionable recommendations based on the currently filtered data.
- **Responsive Design**: Mobile-first layout using Tailwind CSS.
- **Atomic Architecture**: Components organized into Atoms (UI), Molecules (Charts), and Organisms (Dashboard Sections).

## Project Structure

```
/
├── components/
│   ├── ui/          # Atoms (Button, Input, Card)
│   ├── charts/      # Molecules (SalesChart)
│   └── dashboard/   # Organisms (FilterBar, Dashboard Page)
├── services/        # External API logic (Gemini)
├── types.ts         # TypeScript definitions
└── constants.ts     # Mock data
```

## Setup & Running

1. **Install Dependencies**:
   Ensure you have a React environment set up (e.g., Vite).
   ```bash
   npm install react react-dom recharts @google/genai
   npm install -D tailwindcss postcss autoprefixer
   ```

2. **Environment Variables**:
   Create a `.env` file for the Gemini API key (optional for the UI to load, required for the "Analyze" button to work).
   ```
   API_KEY=your_gemini_api_key_here
   ```

3. **Run**:
   ```bash
   npm run dev
   ```

## Design Decisions

- **Why Mock Data?** As per requirements, static data for 2022-2024 is generated in `constants.ts` to simulate a database response.
- **Separation of Concerns**: Logic for fetching AI insights is separated into `services/geminiService.ts` to keep UI components clean.
- **Tailwind**: Used for all styling to avoid CSS file bloat and ensure consistency.
