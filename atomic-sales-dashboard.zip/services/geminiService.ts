import { GoogleGenAI } from "@google/genai";
import { SalesData } from "../types";

// Initialize Gemini Client
// Note: In a real Next.js app, this would be a server action or API route to hide the key.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeSalesData = async (data: SalesData[], threshold: number): Promise<string> => {
  try {
    if (!process.env.API_KEY) {
      return "API Key is missing. Please configure the environment variable.";
    }

    // Limit data sent to context to avoid token limits on large datasets, 
    // though for this mock data it's fine.
    const dataSummary = JSON.stringify(data.slice(0, 30)); 

    const prompt = `
      You are a senior data analyst. Analyze the following sales data JSON.
      Context: The user has filtered for sales above ${threshold}.
      Data: ${dataSummary}
      
      Please provide:
      1. A brief summary of the performance.
      2. Identify the peak month.
      3. One actionable recommendation for next year.
      
      Keep the response concise (under 100 words) and professional.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "No insights generated.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Failed to generate insights. Please try again later.";
  }
};
